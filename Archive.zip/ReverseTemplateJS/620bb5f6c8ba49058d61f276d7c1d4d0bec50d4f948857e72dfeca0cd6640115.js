// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("hardens.com-noevent-en",function(e){},function(e){},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/1260/1283/1284","SGbb7588c3")]);
