// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("ba.com-cancellation-en",function(e){return!1},function(e){return/^BA confirmation of cancellation and refund:/.test(e.subject)||/^Your booking cancellation/.test(e.subject)?STOP:void 0},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/248/373/375","SG0f29a15d")]);
