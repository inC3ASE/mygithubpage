// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("airfrance.com-cancellation-en",function(e){return/check-in cancellation/.test(e.subject)},function(e){return/check-in cancellation/.test(e.subject)?STOP:void 0},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/248/322/323","SG48967df4")]);
