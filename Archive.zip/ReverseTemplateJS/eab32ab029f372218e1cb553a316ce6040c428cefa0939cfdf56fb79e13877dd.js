// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("swiss.com-cancellation-en",function(e){return!1},function(e){return/SWISS Cancellation Email$/.test(e.subject)?STOP:void 0},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/248/603/604","SG40e1a61b")]);
