// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("hotpepper.jp-noevent-jp",function(e){},function(e){},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/1260/1285/1288","SG92de2a83")]);
