// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("expediamail.com-travel-cancellation-en",function(e){return/^cancellation confirmed for/.test(e.subject)},function(e){return/cancellation confirmed for/.test(e.subject)?STOP:void 0},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/1055/1109/1146","SG720db1f0")]);
