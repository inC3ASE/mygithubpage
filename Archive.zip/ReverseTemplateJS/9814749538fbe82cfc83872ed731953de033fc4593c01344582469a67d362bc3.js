// Copyright 2014 Apple Inc.  All Rights Reserved.
new ReverseTemplateList([new ReverseTemplate("tabelog.com-noevent-jp",function(e){},function(e){},"0/1/2/3/4/5/6/5/7/7/7/7/4/8/9/1260/1369/1372","SGd9abc528")]);
